**<u></u>**
<ul>
<li>
<b>In general,</b> <code>ctrl+shift+r</code> for <i></i></li>
<li>
<strike>Many JavaDocs in the Model package</strike>, most JavaDocs done, still missing some in lower
alphabetical classes.
</li>
<li>
Determine which classes should be marked final
</li>
<li>
Decide whether or not to add support for editing multiple images at once</li>
<li>
Create tests to check for null inputs in all methods of the model package</li>
<li>
Tests for all Utils static methods</li></ul>

<b>Adam:</b> <ul>
<li>
JavaDocs for matrix, pixel, programmatic image, model</li>
<li>
set up abstract tests</li>
<li>
README</li>
<li>
IImage wrapper class fixes</li></ul>
<b>Sharwin:</b> <ul>
<li>JavaDocs for Operations </li>
<li>Create messages for import/export for user to read</li>
<li>AFilter Tests</li>
<li>AColorTransform Tests</li>
<li>Channel Tests</li>
<li>EChannelType Tests</li>
<li>Image Tests</li>
<li>Pixel Tests</li>
</ul>