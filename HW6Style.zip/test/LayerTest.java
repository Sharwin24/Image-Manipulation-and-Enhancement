/**
 * Class for tests for the Layer implementation.
 */
public class LayerTest {
// Todo
}