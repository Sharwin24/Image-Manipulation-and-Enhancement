/**
 * Class for testing the Multilayer model implementation.
 */
public class MultiLayerModelTest {

}